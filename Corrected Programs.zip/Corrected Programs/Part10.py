from werkzeug.security import generate_password_hash, check_password_hash

# Example: storing a new user's password
plain_password = "user_password123"
hashed_password = generate_password_hash(plain_password)  # store this in the database

# Later: verifying login
input_password = "user_password123"  # password entered by user during login
stored_hash = hashed_password          # retrieve this from the database

if check_password_hash(stored_hash, input_password):
    print("Login success")
else:
    print("Invalid credentials")

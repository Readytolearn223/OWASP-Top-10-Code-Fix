import hashlib
import os
import base64

def hash_password(password: str) -> str:
    # Generate a random salt
    salt = os.urandom(16)
    # Derive a secure hash using PBKDF2 with SHA-256
    dk = hashlib.pbkdf2_hmac(
        'sha256',                  # Secure hash algorithm
        password.encode('utf-8'),  # Convert password to bytes
        salt,                      # Add salt
        100_000                    # Iterations
    )
    # Store salt + hash together (base64-encoded for storage)
    return base64.b64encode(salt + dk).decode('utf-8')

def verify_password(password: str, stored_hash: str) -> bool:
    # Decode the stored hash back to salt + derived key
    data = base64.b64decode(stored_hash.encode('utf-8'))
    salt, dk = data[:16], data[16:]
    # Recompute the derived key with the same salt and iterations
    new_dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100_000)
    return new_dk == dk

from flask import Flask, request, jsonify
from itsdangerous import URLSafeTimedSerializer
from werkzeug.security import generate_password_hash
from flask_mail import Mail, Message

app = Flask(__name__)

# Configure Flask-Mail (example)
app.config.update(
    MAIL_SERVER='smtp.example.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='your_email@example.com',
    MAIL_PASSWORD='your_password'
)
mail = Mail(app)
serializer = URLSafeTimedSerializer("SECRET_KEY")

@app.route('/request-reset', methods=['POST'])
def request_reset():
    email = request.form['email']
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"message": "If that email exists, a reset link has been sent."}), 200

    # Generate a secure token
    token = serializer.dumps(user.email, salt='password-reset-salt')

    reset_url = f"http://yourdomain.com/reset-password/{token}"

    # Send email with reset link
    msg = Message("Password Reset Request", recipients=[user.email])
    msg.body = f"Click the link to reset your password: {reset_url}"
    mail.send(msg)

    return jsonify({"message": "If that email exists, a reset link has been sent."}), 200

@app.route('/reset-password/<token>', methods=['POST'])
def reset_password(token):
    try:
        email = serializer.loads(token, salt='password-reset-salt', max_age=3600)  # 1 hour expiry
    except:
        return jsonify({"error": "Invalid or expired token"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    new_password = request.form['new_password']
    # Hash the password before storing
    user.password = generate_password_hash(new_password)
    db.session.commit()

    return jsonify({"message": "Password has been reset successfully"}), 200

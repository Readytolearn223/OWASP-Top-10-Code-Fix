from flask import Flask, request, jsonify
from pymongo import MongoClient
import re

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
db = client["mydatabase"]

def sanitize_username(username):
    # Only allow alphanumeric usernames
    return re.sub(r'[^a-zA-Z0-9]', '', username)

@app.route('/user', methods=['GET'])
def get_user():
    raw_username = request.args.get('username', '')
    username = sanitize_username(raw_username)
    
    user = db.users.find_one({"username": username})
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Remove sensitive fields if needed
    user.pop("_id", None)
    
    return jsonify(user)

if __name__ == "__main__":
    app.run(debug=True)

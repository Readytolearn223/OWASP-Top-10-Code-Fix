from flask import Flask, jsonify
from flask_login import login_required, current_user

app = Flask(__name__)

@app.route('/account', methods=['GET'])
@login_required
def get_account():
    # Only return the logged-in user's account
    user = db.query(User).filter_by(id=current_user.id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    return jsonify(user.to_dict())

import sqlite3

def get_user(username: str):
    conn = sqlite3.connect('example.db')  # Connect to your database
    cursor = conn.cursor()
    
    # Use a parameterized query to prevent SQL injection
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    
    user = cursor.fetchone()
    conn.close()
    
    return user

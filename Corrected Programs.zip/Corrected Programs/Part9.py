import requests
from urllib.parse import urlparse

# Define a whitelist of allowed domains
ALLOWED_DOMAINS = ["example.com", "api.example.com"]

def is_allowed_url(url):
    try:
        parsed = urlparse(url)
        return parsed.hostname in ALLOWED_DOMAINS and parsed.scheme in ("http", "https")
    except Exception:
        return False

url = input("Enter URL: ")

if is_allowed_url(url):
    response = requests.get(url)
    print(response.text)
else:
    print("URL is not allowed.")

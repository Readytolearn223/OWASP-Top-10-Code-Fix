from flask import Flask, render_template_string

app = Flask(__name__)

@app.route('/')
def index():
    # Include the script with integrity and crossorigin attributes
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Secure Script Load</title>
        <script src="https://cdn.example.com/lib.js"
                integrity="sha384-<HASH_HERE>"
                crossorigin="anonymous"></script>
    </head>
    <body>
        <h1>Secure Script Example</h1>
    </body>
    </html>
    """
    return render_template_string(html_content)

if __name__ == "__main__":
    app.run(debug=True)
